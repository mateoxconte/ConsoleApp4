﻿using ConsoleApp4.data.conexion;
using ConsoleApp4.data.implementacion;
using ConsoleApp4.Dominio;
using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        string connectionString = "Data Source=MSI\\SQLEXPRESS01;Initial Catalog=facturacion;Integrated Security=True;Trust Server Certificate=True";

        using (UnitOfWork uow = new UnitOfWork(connectionString))
        {
            // -----------------------------
            // 1️⃣ Guardar una factura
            // -----------------------------
            facturas f = new facturas
            {
                cliente = "Juan Pérez",
                fecha = DateTime.Now,
                idFormaPago = 1
            };

            f.AgregarDetalle(new detalFactura { articulo = new Articulo { id = 1 }, cantidad = 2 });
            f.AgregarDetalle(new detalFactura { articulo = new Articulo { id = 2 }, cantidad = 5 });

            bool ok = uow.FacturaRepository.Save(f);
            if (ok)
            {
                uow.Commit();
                Console.WriteLine("Factura guardada con éxito.");
            }
            else
            {
                Console.WriteLine("Error al guardar la factura.");
            }

            Console.WriteLine(new string('-', 40));

            // -----------------------------
            // 2️⃣ Listar una forma de pago por ID
            // -----------------------------
            Console.Write("Ingrese el ID de la forma de pago a consultar: ");
            int idFormaPago = int.Parse(Console.ReadLine());

           var formaPago = uow.FpRepository.GetByid(idFormaPago);
            if (formaPago != null)
            {
                Console.WriteLine($"ID: {formaPago.id}, Nombre: {formaPago.nombre}");
            }
            else
            {
                Console.WriteLine("No se encontró la forma de pago.");
            }

            Console.WriteLine(new string('-', 40));

            // -----------------------------
            // 3️⃣ GetAll de todos los artículos
            // -----------------------------
            List<Articulo> articulos = uow.ArticuloRepository.GetAll();
            Console.WriteLine("Listado de todos los artículos:");
            foreach (var art in articulos)
            {
                Console.WriteLine($"ID: {art.id}, Nombre: {art.nombre}, Precio: {art.precio}");
            }

            Console.WriteLine("\nOperaciones finalizadas. Presione ENTER para salir.");
            Console.ReadLine();
        }
    }
}





