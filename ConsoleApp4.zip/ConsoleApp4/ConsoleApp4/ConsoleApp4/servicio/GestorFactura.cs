﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp4.Dominio;
using System.Data;
using Microsoft.Data.SqlClient;
using ConsoleApp4;
using ConsoleApp4.Dominio;
using ConsoleApp4.data.conexion;



namespace ConsoleApp4.servicio
{

    public class GestorFactura
    {
        public class GestorProducto
        {
            private readonly UnitOfWork _unitOfWork;
            public GestorProducto(UnitOfWork unitOfWork)
            {
                _unitOfWork = unitOfWork;
            }
          public bool GuardarFactura(facturas ofacturas)
            {
                try
                {
                    _unitOfWork.FacturaRepository.Save(ofacturas);
                    _unitOfWork.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;

                }
            }
            public List<Articulo> GetAll()
            {
                return _unitOfWork.ArticuloRepository.GetAll();
            }
            public Articulo GetByid(int id)
            {
                return _unitOfWork.ArticuloRepository.GetByid(id);
            }
            public bool GuardarArticulo(Articulo articulo)
            {
                _unitOfWork.ArticuloRepository.save(articulo);
                _unitOfWork.Commit();
                return true;
            }
            public bool GuardarFP(Fp fp) 
            {

                _unitOfWork.FpRepository.save(fp);
                _unitOfWork.Commit();
                return true;
            }
            public List<Fp> GetAllFP()
            {
                return _unitOfWork.FpRepository.GetAll();
            }
            public Fp GetByidFP(int id)
            {
                return _unitOfWork.FpRepository.GetByid(id);
            }
            public List<facturas> GetAllFacturas()
            {
                return _unitOfWork.FacturaRepository.GetAll();
            }

        }
        
    }
}
