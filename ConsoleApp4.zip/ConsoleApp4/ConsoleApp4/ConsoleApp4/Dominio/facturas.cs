﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4.Dominio
{
    public class facturas
    {
        public int nroFactura { get; set; }
        public string cliente { get; set; }

        public DateTime fecha { get; set; }

        public int idFormaPago { get; set; }

        public List<detalFactura> Detalles;
        public facturas()
        {
            Detalles = new List<detalFactura>();

        }
        public void AgregarDetalle(detalFactura d)
        {
            if(d != null)
            {
                Detalles.Add(d); // agrega el detalle a la lista
            }
        }
        public void QuitarDetalle(int index)
        {
          Detalles.RemoveAt(index); // elimina el detalle en la posicion index

        }
      //  public decimal Total()
       // {
      //      decimal total = 0;
      //      foreach (var d in Detalles)
      //      {
     //           total += d.subtotal; // suma el subtotal de cada detalle
      //
      // return total;
           
      //  }
        
          
        
    }
}
