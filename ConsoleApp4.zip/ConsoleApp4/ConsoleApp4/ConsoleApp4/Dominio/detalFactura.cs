﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
namespace ConsoleApp4.Dominio
{
    public class detalFactura
    {
        public Articulo articulo { get; set; }
        public int cantidad { get; set; }

    }
}
