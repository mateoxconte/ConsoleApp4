﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp4.Dominio;
using Microsoft.Data.SqlClient;

namespace ConsoleApp4.data.interfaces
{
    public interface IfacturaRepository
    {
        List<facturas> GetAll();
        facturas GetById(int id);
        bool Save(facturas product);
    }
}
