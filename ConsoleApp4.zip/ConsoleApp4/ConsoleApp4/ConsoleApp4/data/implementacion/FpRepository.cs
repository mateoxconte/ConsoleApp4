﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp4.Dominio;
using Microsoft.Data.SqlClient;
using System.Data;
using ConsoleApp4.data.interfaces;
using ConsoleApp4.data.conexion;


namespace ConsoleApp4.data.implementacion
{
 
    public class FpRepository : IFpRepository
    {
        private readonly SqlConnection _connection;
        private readonly SqlTransaction _transaction;
        private string cnnString = Properties.Resources.CadenaConexionLocal;
        public FpRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }
        public bool delete(Fp fp)
        {
            throw new NotImplementedException();
        }

        public List<Fp> GetAll()
        {
            List<Fp> list = new List<Fp>();
            using (SqlCommand cmd = new SqlCommand("SP_GetAll_FP", _connection, _transaction))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Fp fp = new Fp();
                        fp.id = Convert.ToInt32(reader["idFormaPago"]); // columna en tu tabla
                        fp.nombre = reader["nombre"].ToString();

                        list.Add(fp);
                    }
                    return list;
                }

            }
        }   
        

        public Fp GetByid(int id)
        {
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();
            Fp fp = null;
            using (SqlCommand cmd = new SqlCommand("SP_GetById_FPP", _connection, _transaction))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        fp = new Fp();
                        fp.id = Convert.ToInt32(reader[0]); // columna en tu tabla
                        fp.nombre = reader["nombre"].ToString();
                    }
                }
                return fp;
            }
        }

        public bool save(Fp fp)
        {
            try
            {
                var comando = new SqlCommand("SP_Save_FP", _connection, _transaction);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@descripcion",fp.nombre );
                comando.ExecuteNonQuery();

                return true;
            }
            catch (SqlException ex)
            {
                //gestionar error...
                return false;
            }
        }
    }
}
