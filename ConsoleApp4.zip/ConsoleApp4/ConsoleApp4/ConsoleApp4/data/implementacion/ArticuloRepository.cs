﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp4.Dominio;
using Microsoft.Data.SqlClient;
using System.Data;
using ConsoleApp4.data.interfaces;
using ConsoleApp4.data.conexion;


namespace ConsoleApp4.data.implementacion
{
    public class ArticuloRepository : IarticuloRepository
    {
        public readonly SqlConnection _connection;
        public readonly SqlTransaction _transaction;
        private string cnnString = Properties.Resources.CadenaConexionLocal;
        public ArticuloRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }
        public bool delete(Articulo articulo)
        {
            throw new NotImplementedException();
        }

        public  List<Articulo> GetAll()
        {
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();

            List<Articulo> lista = new List<Articulo> ();
            using (SqlCommand cmd = new SqlCommand("SP_GetAll_Articulos", _connection, _transaction))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                using (SqlDataReader reader = cmd.ExecuteReader())
                    while (reader.Read())
                    {
                        Articulo articulo = new Articulo ();
                        articulo.id = reader.GetInt32(0);
                        articulo.nombre = reader.GetString(1);
                        articulo.precio = reader.GetDecimal(2);
                        lista.Add (articulo);

                    }
                return lista;
            }


        }

        public Articulo GetByid(int id)
        {
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();
            Articulo articulo = null;
            using (SqlCommand cmd = new SqlCommand("SP_GetById_Articuloo", _connection, _transaction))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                using (SqlDataReader reader = cmd.ExecuteReader())
                    if (reader.Read())
                    {
                        articulo = new Articulo();
                        articulo.id = reader.GetInt32(0);
                        articulo.nombre = reader.GetString(1);
                        articulo.precio = reader.GetDecimal(2);
                    }
                return articulo;
            }

        }

        public bool save(Articulo articulo)

        {
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();
            try
            {
                
                    var comando = new SqlCommand("SP_Insertar_Articulo", _connection, _transaction);
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.AddWithValue("@nombre", articulo.nombre);
                    comando.Parameters.AddWithValue("@precio", articulo.precio);
                    comando.ExecuteNonQuery();
                    return true;

                
            }
            catch (Exception ex)
            {
                return false;
            }

        }

    }
}
