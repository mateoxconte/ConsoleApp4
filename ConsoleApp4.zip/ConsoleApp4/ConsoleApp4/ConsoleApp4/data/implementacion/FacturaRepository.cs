﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp4.Dominio;
using System.Data;
using Microsoft.Data.SqlClient;
using ConsoleApp4.data.interfaces;
using ConsoleApp4.data.conexion;
using ConsoleApp4.servicio;
using ConsoleApp4;  
namespace ConsoleApp4.data.implementacion
{
    public class FacturaRepository : IfacturaRepository
    {
      
        public readonly SqlConnection _connection;
         public readonly SqlTransaction _transaction;
        public FacturaRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public List<facturas> GetAll()

        {
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();
            using (var comando = new SqlCommand("SP_GetAll_Facturas", _connection, _transaction))
            {
                var lista = new List<facturas>();
                using (var reader = comando.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var factura = new facturas
                        {
                            nroFactura = reader.GetInt32(0),
                            cliente = reader.GetString(1),
                            fecha = reader.GetDateTime(2),
                            idFormaPago = reader.GetInt32(3)
                        };
                        lista.Add(factura);
                    }
                }
                return lista;
            }
        }

        public facturas GetById(int id)
        {
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();
            facturas facturas = null;
            using (var comando = new SqlCommand("SP_GetById_Facturaa", _connection, _transaction))
            {
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@nroFactura", id);
                using (var reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var factura = new facturas
                        {
                            nroFactura = reader.GetInt32(0),
                            cliente = reader.GetString(1),
                            fecha = reader.GetDateTime(2),
                            idFormaPago = reader.GetInt32(3),
                            
                        };
                        return factura;
                    }
                }
            }
            return null; // Si no se encuentra la factura
        }

        public bool Save(facturas ofacturas)
        {
            try
            {
                // Asegúrate de abrir la conexión si no lo está
                if (_connection.State != ConnectionState.Open)
                    _connection.Open();

                // Comando para insertar factura (maestro)
                using (var comando = new SqlCommand("SPInsertar_maestro", _connection, _transaction))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.AddWithValue("@cliente", ofacturas.cliente);
                    comando.Parameters.AddWithValue("@fecha", ofacturas.fecha);
                    comando.Parameters.AddWithValue("@idFormaPago", ofacturas.idFormaPago);

                    // Parametro de salida para el número de factura
                    var param = new SqlParameter("@nroFactura", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    comando.Parameters.Add(param);

                    comando.ExecuteNonQuery();
                    int nroFactura = (int)param.Value;

                    // Insertar detalles
                    foreach (var d in ofacturas.Detalles)
                    {
                        using (var cmdDetalle = new SqlCommand("SPInsertar_detallee", _connection, _transaction))
                        {
                            cmdDetalle.CommandType = CommandType.StoredProcedure;
                            cmdDetalle.Parameters.AddWithValue("@nroFactura", nroFactura);
                            cmdDetalle.Parameters.AddWithValue("@idArticulo", d.articulo.id);
                            cmdDetalle.Parameters.AddWithValue("@cantidad", d.cantidad);

                            // Parametro de salida para idDetalle (identity)
                            var paramDetalle = new SqlParameter("@idDetalle", SqlDbType.Int)
                            {
                                Direction = ParameterDirection.Output
                            };
                            cmdDetalle.Parameters.Add(paramDetalle);

                            cmdDetalle.ExecuteNonQuery();
                            int idDetalle = (int)paramDetalle.Value; // ahora sí, SQL Server lo generó
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                // Mostrar el error real
                Console.WriteLine("Error en Save: " + ex.Message);
                return false;
            }
        }
    }
}
