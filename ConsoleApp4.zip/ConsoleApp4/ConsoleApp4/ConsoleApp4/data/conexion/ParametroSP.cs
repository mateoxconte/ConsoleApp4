﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace ConsoleApp4.data.conexion
{
    public class ParametroSP
    {
        public string Name { get; set; }
        public object valor { get; set; }
        public ParametroSP(string name, object valor)
        {
            Name = name;
            this.valor = valor;
        }
    }
}
