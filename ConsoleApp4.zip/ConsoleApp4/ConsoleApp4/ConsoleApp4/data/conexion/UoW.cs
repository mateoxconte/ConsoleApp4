﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using ConsoleApp4.data.implementacion;
using ConsoleApp4.data.interfaces;

namespace ConsoleApp4.data.conexion
{
    public class UnitOfWork : IDisposable
    {
        
        public readonly SqlConnection _connection;
        public SqlTransaction _transaction;
        private IfacturaRepository _facturaRepository;
        private IarticuloRepository _articuloRepository;
        private IFpRepository _fpRepository;
        public UnitOfWork(string cnnString)
        {


            _connection = new SqlConnection(cnnString);
            _connection.Open();
            _transaction = _connection.BeginTransaction();


        }
        public IfacturaRepository FacturaRepository
        {
            get
            {
                if (_facturaRepository == null)
                {
                    _facturaRepository = new FacturaRepository(_connection, _transaction);
                }
                return _facturaRepository;
            }
        }
        public IarticuloRepository ArticuloRepository
        {
            get
            {
                if (_articuloRepository == null)
                {
                    _articuloRepository = new ArticuloRepository(_connection, _transaction);
                }
                return _articuloRepository;
            }
        }
        public IFpRepository FpRepository
        {
            get
            {
                if (_fpRepository == null)
                {
                    _fpRepository = new FpRepository(_connection, _transaction);
                }
                return _fpRepository;
            }
        }
        public void Commit()
        {
            try
            {
                _transaction.Commit();
            }
            catch
            {
                _transaction.Rollback();
                throw;
            }
            finally
            {
                _connection.Close();
            }
        }
        public void Dispose()
        {
            if (_transaction != null)
            {
                _transaction.Dispose();
            }
            if (_connection != null)
            {
                _connection.Close();
                _connection.Dispose();
            }

        }
    }
}
